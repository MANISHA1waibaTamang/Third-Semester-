<?php 
include("connection.php");
session_start();
$id =$_GET['id'];
$userprofile=$_SESSION['user_name'];
if($userprofile==true)
{

}
else{
    header('location:login.php');
}
$query = "SELECT * FROM FORM5 where id= '$id'";
$data = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($data);

$lamguage=$result['language'];
$language1=explode(", ", $language);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css"> <title>PHP CRUD Operations</title>
</head>
<body>
    
</body>
</html>
